package com.voicectl

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

private const val HELP = """Что можно говорить (после имени бота):

📱 Экран и замок
• включи планшет / проснись · заблокируй
• разблокируй 270420 / по паролю … / введи пароль …

🚀 Приложения и навигация
• открой / запусти / зайди в / включи + название
• выйди из ютуба / домой / назад / недавние
• прокрути вниз / вверх · уведомления · скриншот

💬 Сообщения (бот сам найдёт чат, потом спросит текст)
• напиши в телеграме маме → «Диктуйте» → говоришь текст → отправляется
• напиши маме в ватсапе
• «отмена» во время диктовки — отменить
• зайди в чат с мама · напиши сообщение … · отправь

📝 Заметки
• запиши в заметки купить молоко
• создай заметку → диктуешь текст

📞 Звонки
• позвони маме / позвони 89991234567
• ответь · сбрось · громкая связь

🎵 Музыка
• включи музыку / включи песню Кино (с устройства)
• включи плейлист Любимое в яндекс музыке
• включи песню Тоха в яндекс музыке · включи мою волну
• стоп · продолжай · следующее · громче · тише

👁 Экран
• нажми на крестик / меню / лайк / принять / пропустить
• нажми на «Подписаться» · закрой рекламу
• что на экране — прочитает вслух

• несколько команд: «выйди из ютуба и зайди в телеграм»
• отключись — остановить бота"""

class MainActivity : Activity() {
    private lateinit var info: TextView
    private lateinit var logV: TextView
    private lateinit var go: Button
    private lateinit var names: EditText
    private lateinit var pin: EditText
    private val h = Handler(Looper.getMainLooper())
    private val tick = object : Runnable { override fun run() { refresh(); h.postDelayed(this, 1000) } }
    private val bg = 0xFF0F1117.toInt()
    private val card = 0xFF1B1F2A.toInt()
    private val acc = 0xFF6C8CFF.toInt()
    private val dim = 0xFF9AA0B0.toInt()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(c: Int) = GradientDrawable().apply { setColor(c); cornerRadius = dp(14).toFloat() }
    private fun tv(t: String, s: Float, c: Int) = TextView(this).apply { text = t; textSize = s; setTextColor(c) }
    private fun et(hint: String, v: String) = EditText(this).apply {
        setText(v); this.hint = hint; setTextColor(Color.WHITE); setHintTextColor(0xFF777B88.toInt())
        background = rounded(card); setPadding(dp(14), dp(12), dp(14), dp(12))
    }
    private fun btn(t: String, c: Int, f: () -> Unit) = Button(this).apply {
        text = t; isAllCaps = false; setTextColor(Color.WHITE); textSize = 16f; background = rounded(c)
        setOnClickListener { f() }
        layoutParams = LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(10) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val p = getSharedPreferences("vc", 0)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(44), dp(20), dp(24)) }
        root.addView(tv("🎙 Голосовое управление", 26f, Color.WHITE).apply { setTypeface(typeface, Typeface.BOLD) })
        root.addView(tv("Скажи имя бота и команду", 14f, dim))
        info = tv("", 15f, Color.WHITE).apply { setPadding(0, dp(16), 0, dp(10)) }
        root.addView(info)
        root.addView(tv("Имя бота (можно несколько через запятую)", 12f, dim))
        names = et("джарвис", p.getString("names", "джарвис") ?: "джарвис"); root.addView(names)
        root.addView(tv("PIN для «разблокируй» (необязательно)", 12f, dim).apply { setPadding(0, dp(10), 0, 0) })
        pin = et("", p.getString("pin", "") ?: "").apply { inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD }
        root.addView(pin)
        root.addView(btn("1. Выдать разрешения", card) { perm() })
        root.addView(btn("2. Включить службу доступности", card) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("3. Не засыпать в фоне (батарея)", card) { battery() })
        go = btn("▶ Запустить", acc) { toggle() }; root.addView(go)
        logV = tv("", 13f, 0xFFB8F0C8.toInt()).apply { setPadding(0, dp(16), 0, 0) }; root.addView(logV)
        root.addView(tv(HELP, 13f, dim).apply { setPadding(0, dp(20), 0, 0) })
        setContentView(ScrollView(this).apply { setBackgroundColor(bg); addView(root) })
        window.statusBarColor = bg
        Brain.onLog = { logV.text = Brain.logs.joinToString("\n") }
    }

    private fun battery() = startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))

    private fun perm() {
        val l = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS, Manifest.permission.ANSWER_PHONE_CALLS)
        if (Build.VERSION.SDK_INT >= 33) { l.add(Manifest.permission.POST_NOTIFICATIONS); l.add(Manifest.permission.READ_MEDIA_AUDIO) }
        else l.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        requestPermissions(l.toTypedArray(), 1)
    }

    private fun toggle() {
        if (Brain.running) { getSharedPreferences("vc", 0).edit().putBoolean("auto", false).apply(); stopService(Intent(this, VoiceService::class.java)); return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { perm(); return }
        getSharedPreferences("vc", 0).edit().putString("names", names.text.toString()).putString("pin", pin.text.toString()).putBoolean("auto", true).apply()
        startForegroundService(Intent(this, VoiceService::class.java))
    }

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        info.text = (if (mic) "✅" else "❌") + " Микрофон\n" +
            (if (ControlService.inst != null) "✅" else "❌") + " Служба доступности\n" +
            (if (Brain.running) "🟢 Слушаю" else "⚪ Остановлено")
        go.text = if (Brain.running) "■ Остановить" else "▶ Запустить"
        logV.text = Brain.logs.joinToString("\n")
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }
    override fun onDestroy() { Brain.onLog = null; super.onDestroy() }
}
